package com.springsecurity.react.authentication;

import com.springsecurity.react.config.JwtTokenGenerator;
import com.springsecurity.react.dto.*;
import com.springsecurity.react.model.*;
import com.springsecurity.react.signup.SignUpRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

@RestController
public class AuthenticationController {

    private static final Logger log = LogManager.getLogger(AuthenticationController.class);

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenGenerator jwtTokenUtil;

    @Autowired
    private SignUpRepository userRepository;

    @Autowired
    private RefreshTokenRepository refreshTokenRepository;

    @Autowired
    private TokenBlocklistService tokenBlocklistService;

    @PostMapping("/authenticate")
    public ResponseEntity<AuthResponseDTO> authenticate(@RequestBody AuthRequestDTO authRequest) throws Exception {
        log.info("---Authentication Controller started with authenticate method..!");
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword())
        );
        SignUp userDetails = userRepository.findByUserName(authRequest.getUserName());
        String token = jwtTokenUtil.generateToken(userDetails.getId(), userDetails.getUserName(), userDetails.getRole());
        log.info("---JWT Token Created Successfully......!");
        String refreshToken = jwtTokenUtil.generateRefreshToken(userDetails.getUserName());
        log.info("---Refresh Token Created Successfully......!");
        if (token != null) {
            RefreshToken refreshTokenObj = new RefreshToken()
                    .builder()
                    .refreshToken(refreshToken)
                    .userName(authRequest.getUserName())
                    .build();
            refreshTokenRepository.save(refreshTokenObj);
        } else {
            return ResponseEntity.badRequest().body(new AuthResponseDTO("Jwt token is required"));
        }
        return ResponseEntity.ok(new AuthResponseDTO(token, refreshToken));
    }

    @PostMapping("/refreshToken")
    public ResponseEntity<AuthResponseDTO> generateNewAccessToken(@RequestBody RefreshTokenReqDTO refreshToken) {
        String userName = jwtTokenUtil.extractUsername(refreshToken.getRefreshToken());
        String accessToken = null;
        if (userName != null) {
            SignUp userDetails = userRepository.findByUserName(userName);
            accessToken = jwtTokenUtil.generateToken(userDetails.getId(), userDetails.getUserName(), userDetails.getRole());
        } else {
            return ResponseEntity.badRequest().body(new AuthResponseDTO("Refresh token is required"));
        }
        return ResponseEntity.ok(new AuthResponseDTO(accessToken));
    }

    @PostMapping("/logoutApi")
    public ResponseEntity<BlockedTokenResDTO> logoutForm(@RequestBody BlockedTokenDTO blockedTokenDTO) {
        tokenBlocklistService.blockToken(blockedTokenDTO.getBlockedJwtToken());
        return ResponseEntity.ok(new BlockedTokenResDTO("Token is Blocked"));
    }
}

