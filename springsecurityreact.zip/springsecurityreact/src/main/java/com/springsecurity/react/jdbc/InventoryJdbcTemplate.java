package com.springsecurity.react.jdbc;

import com.springsecurity.react.model.Inventory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Profile("jdbc")
public class InventoryJdbcTemplate {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Inventory> findAll() {
        String query = "SELECT * FROM inventory";
        return jdbcTemplate.query(query, ((rs, rowNum) -> {
            return new Inventory(rs.getLong("id"), rs.getString("product"),
                    rs.getLong("quantity"), rs.getDouble("price"), rs.getString("created_by"),
                    rs.getString("created_date")
            );
        }));
    }
}
