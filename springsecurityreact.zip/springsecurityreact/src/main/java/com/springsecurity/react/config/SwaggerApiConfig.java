package com.springsecurity.react.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class SwaggerApiConfig {

    //Need to environment and versions in swagger so that user can select versions
    @Bean
    public OpenAPI openAPI() {
        Server localServer = new Server();
        localServer.setUrl("http://localhost:8080");
        localServer.setDescription("This is Local Environment");
        Server prodServer = new Server();
        prodServer.setUrl("http://localhost:8000/prod");
        prodServer.setDescription("This is Prod Server");
        Contact contact = new Contact();
        contact.setEmail("test@gmail.com");
        contact.setName("Test Prod Help");
        return new OpenAPI()
                .addSecurityItem(new SecurityRequirement().addList("Bearer Authentication"))
                .components(new Components().addSecuritySchemes("Bearer Authentication", createAPIKeyScheme()))
                .servers(List.of(prodServer, localServer))
                .info(new Info()
                .title("Swagger API Testing").contact(new Contact().name("Vmanico"))
                .description("Swagger API Testing for React and Spring boot Application")
                .version("1.0").version("2.0"));
    }

    @Bean
    public OpenAPI openAPIv2() {
        return new OpenAPI()
                .addSecurityItem(new SecurityRequirement().addList("Bearer Authentication"))
                .components(new Components().addSecuritySchemes("Bearer Authentication", createAPIKeyScheme()))
                .info(new Info()
                        .title("Swagger API Testing - v2")
                        .contact(new Contact().name("Vmanico"))
                        .description("Swagger API Testing for React and Spring Boot Application (v2)")
                        .version("2.0"));
    }
    private SecurityScheme createAPIKeyScheme() {
        return new SecurityScheme().type(SecurityScheme.Type.HTTP)
                .bearerFormat("JWT")
                .scheme("bearer");
    }
}
