package com.springsecurity.react.order;

import com.springsecurity.react.dto.MapperDTO;
import com.springsecurity.react.model.Order;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {

    private static final Logger log = LogManager.getLogger(OrderController.class);

    @Autowired
    private OrderService orderService;

    /// User need to access the list for certain orders only
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/findAll")
    public ResponseEntity<List<Order>> findAll() {
        log.info("----Order Controller with findAll method started in controller to fetch all records-------");
        List<Order> orderList = orderService.findAll();
        return ResponseEntity.ok(orderList);
    }

    @PreAuthorize("hasAnyAuthority('USER','ADMIN')")
    @PostMapping("/save")
    public ResponseEntity<Order> save(@RequestBody Order order) {
        log.info("----Order Controller with Save method started in controller with User Data-------" + MapperDTO.mapObjectToJson(order));
        Order orderObj = orderService.save(order);
        return ResponseEntity.ok(orderObj);
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/update/{id}")
    public void update(@RequestBody Order order, @PathVariable("id") Long id) {
        log.info("----Order Controller with Update method started in controller with User Data-------" + MapperDTO.mapObjectToJson(order));
        orderService.update(id, order);
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable("id") Long id) {
        log.info("----Order Controller with Delete method started in controller with ID-------" + id);
        orderService.delete(id);
    }
}
