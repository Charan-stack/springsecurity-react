package com.springsecurity.react.dto;

import lombok.Data;

@Data
public class AuthRequestDTO {
    private String userName;
    private String password;
}

