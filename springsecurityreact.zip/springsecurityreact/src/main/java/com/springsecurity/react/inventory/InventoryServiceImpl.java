package com.springsecurity.react.inventory;

import com.springsecurity.react.jdbc.InventoryJdbcTemplate;
import com.springsecurity.react.model.Inventory;
import jakarta.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class InventoryServiceImpl implements InventoryService {

    private static final Logger log = LogManager.getLogger(InventoryServiceImpl.class);

    @Autowired
    private InventoryRepository inventoryRepository;

    private InventoryJdbcTemplate inventoryJdbcTemplate;

    public InventoryServiceImpl (InventoryRepository inventoryRepository, InventoryJdbcTemplate inventoryJdbcTemplate){
        this.inventoryRepository = inventoryRepository;
        this.inventoryJdbcTemplate = inventoryJdbcTemplate;
    }


    @Value("${spring.profiles.active}")
    private String activeProfile;

    @Override
    public List<Inventory> findAll() {
        log.info("---InventoryServiceImpl with findAll method-----");
        List<Inventory> inventoryList = new ArrayList<>();
        if(activeProfile.equals("jpa")) {
            inventoryList = inventoryRepository.findAll();
        }else {
            inventoryList = inventoryJdbcTemplate.findAll();
        }
        return inventoryList;
    }



    @Override
    public Inventory save(Inventory inventory) {
        log.info("---InventoryServiceImpl with Save method-----");
        return inventoryRepository.save(inventory);
    }

    @Override
    public void update(Inventory inventory, Long id) {
        log.info("---InventoryServiceImpl with Update method-----");
        Optional<Inventory> invObj = inventoryRepository.findById(id);
        if (invObj.isPresent()) {
            Inventory invUpdateObj = invObj.get();
            invUpdateObj.setPrice(inventory.getPrice());
            invUpdateObj.setProduct(inventory.getProduct());
            invUpdateObj.setQuantity(inventory.getQuantity());
            inventoryRepository.save(invUpdateObj);
        }

    }

    @Override
    public void delete(Long id) {
        log.info("---InventoryServiceImpl with Delete method-----");
        inventoryRepository.deleteById(id);
    }

    @Override
    public Inventory findById(Long id) {
        Optional<Inventory> inventory = inventoryRepository.findById(id);
        return inventory.get();
    }
}
