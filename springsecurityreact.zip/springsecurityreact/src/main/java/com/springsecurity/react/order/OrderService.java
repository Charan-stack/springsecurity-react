package com.springsecurity.react.order;

import com.springsecurity.react.model.Order;

import java.util.List;

public interface OrderService {

    public List<Order> findAll();
    public Order save(Order order);
    public void update(Long id, Order order);
    public void delete(Long id);
}
