package com.springsecurity.react.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserNameDTO {

    @NotBlank
    @Size(max = 10, min = 2, message = "User name not found")
    private String userName;

}
