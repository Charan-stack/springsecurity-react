package com.springsecurity.react.exception;

public class ExceptionResponse extends RuntimeException {
    public ExceptionResponse(String message) {
        super(message);
    }
}
