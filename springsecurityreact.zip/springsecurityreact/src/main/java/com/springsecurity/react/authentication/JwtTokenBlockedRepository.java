package com.springsecurity.react.authentication;

import com.springsecurity.react.model.BlockedJwtToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JwtTokenBlockedRepository extends JpaRepository<BlockedJwtToken, Long> {

    boolean existsByBlockedToken(String token);

    BlockedJwtToken findByBlockedToken(String token);
}
