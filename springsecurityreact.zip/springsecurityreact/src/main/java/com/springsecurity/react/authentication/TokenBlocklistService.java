package com.springsecurity.react.authentication;

import com.springsecurity.react.dto.BlockedTokenResDTO;
import com.springsecurity.react.model.BlockedJwtToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TokenBlocklistService {

    @Autowired
    private JwtTokenBlockedRepository jwtTokenBlockedRepository;

    public BlockedTokenResDTO blockToken(String token) {
        BlockedJwtToken blockedToken = new BlockedJwtToken()
                .builder()
                .blockedToken(token)
                .build();
        jwtTokenBlockedRepository.save(blockedToken);
        return new BlockedTokenResDTO("Token is Blocked");
    }

    public boolean isTokenBlocked(String token) {
        return jwtTokenBlockedRepository.existsByBlockedToken(token);
    }
}
