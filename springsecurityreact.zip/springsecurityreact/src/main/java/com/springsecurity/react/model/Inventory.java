package com.springsecurity.react.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@Data
@NoArgsConstructor
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "product")
    private String product;

    @Column(name = "quantity")
    private Long quantity;

    @Column(name = "price")
    private Double price;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    private String createdDate;

    public Inventory(Long id, String product, Long quantity, Double price, String createdBy, String createdDate) {
        this.id = id;
        this.product = product;
        this.quantity = quantity;
        this.price = price;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
    }
}
