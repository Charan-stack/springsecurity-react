package com.springsecurity.react.inventory;

import com.springsecurity.react.dto.MapperDTO;
import com.springsecurity.react.model.Inventory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    private static final Logger log = LogManager.getLogger(InventoryController.class);

    @Autowired
    private InventoryService inventoryService;

    @GetMapping("/findAll")
    public ResponseEntity<List<Inventory>> findAll() {
        log.info("---Inventory Controller with findAll method started in controller-------");
        List<Inventory> inventoryList = inventoryService.findAll();
        return ResponseEntity.ok(inventoryList);
    }

    @GetMapping("/findById")
    public Inventory findById(@RequestParam Long id) {
        return inventoryService.findById(id);
    }
    @PostMapping("/save")
    public ResponseEntity<Inventory> save(@RequestBody Inventory inventory, @AuthenticationPrincipal UserDetails userDetails) {
        log.info("---Inventory Controller with Save method started in controller with User Save Object-------" + MapperDTO.mapObjectToJson(inventory));
        Inventory inventoryObj = inventoryService.save(inventory);
        return ResponseEntity.ok(inventoryObj);
    }

    @PutMapping("/update/{id}")
    public void update(@RequestBody Inventory inventory, @PathVariable("id") Long id) {
        log.info("---Inventory Controller with Update method started in controller with User Update Object-------" + MapperDTO.mapObjectToJson(inventory));
        inventoryService.update(inventory, id);
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable("id") Long id) {
        log.info("---Inventory Controller with Delete method started in controller with ID-------" + id);
        inventoryService.delete(id);
    }
}
