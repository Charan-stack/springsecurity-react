package com.springsecurity.react.exception;

public class OrderRunTimeException extends RuntimeException{
    public OrderRunTimeException(String message) {
        super(message);
    }
}
