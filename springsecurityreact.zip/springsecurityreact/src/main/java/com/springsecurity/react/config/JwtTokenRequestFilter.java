package com.springsecurity.react.config;

import com.springsecurity.react.dto.UserNameDTO;
import com.springsecurity.react.authentication.TokenBlocklistService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtTokenRequestFilter extends OncePerRequestFilter {

    private static final Logger log = LogManager.getLogger(JwtTokenRequestFilter.class);

    @Autowired
    private JwtTokenGenerator jwtTokenUtil;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private TokenBlocklistService tokenBlocklistService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        log.info("----JwtTokenRequestFilter stared for Requesting the Jwt token for authentication-----");
        final String authorizationHeader = request.getHeader("Authorization");

        String username = null;
        String jwt = null;
        UserNameDTO userNameDTO = new UserNameDTO();;
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {

            jwt = authorizationHeader.substring(7);
                if (tokenBlocklistService.isTokenBlocked(jwt)) {
                    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    response.getWriter().write("This token is blocked or invalid..!");
                    log.info("-----Jwt Token is Blocked -----");
                    return;
                }
            username = jwtTokenUtil.extractUsername(jwt);
            userNameDTO.setUserName(username);
        }
            if (username !=null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                if (jwtTokenUtil.validateToken(jwt, username)) {
                    UsernamePasswordAuthenticationToken authenticationToken =
                            new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                    authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authenticationToken);
                }
            }
            log.info("----JwtTokenRequestFilter JWT token is successfully generated for Authentication-----");
            chain.doFilter(request, response);
        }
    }

