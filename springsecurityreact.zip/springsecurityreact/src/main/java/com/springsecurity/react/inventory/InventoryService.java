package com.springsecurity.react.inventory;

import com.springsecurity.react.model.Inventory;

import java.util.List;

public interface InventoryService {

    public List<Inventory> findAll();
    public Inventory save(Inventory inventory);
    public void update(Inventory inventory, Long id);
    public void delete(Long id);
    Inventory findById(Long id);
}
