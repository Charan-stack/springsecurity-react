package com.springsecurity.react.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import java.util.UUID;

@Entity
public class TestUUid extends Base{

    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID tuId;
}
