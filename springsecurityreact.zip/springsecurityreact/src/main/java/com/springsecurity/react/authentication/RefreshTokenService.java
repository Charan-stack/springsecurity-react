package com.springsecurity.react.authentication;

import com.springsecurity.react.model.RefreshToken;

public interface RefreshTokenService {

    public RefreshToken save(RefreshToken refreshToken);
}
