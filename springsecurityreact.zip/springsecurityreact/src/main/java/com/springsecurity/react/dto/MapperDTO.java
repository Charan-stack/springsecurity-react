package com.springsecurity.react.dto;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MapperDTO {

    public static String mapObjectToJson(Object object) {
        try {
            return new ObjectMapper().writeValueAsString(object);
        } catch (Exception exception) {
            System.out.printf("exception.getCause();");
        }
        return null;
    }
}
