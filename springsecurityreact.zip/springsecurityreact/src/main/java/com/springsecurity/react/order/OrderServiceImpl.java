package com.springsecurity.react.order;

import com.springsecurity.react.exception.OrderRunTimeException;
import com.springsecurity.react.model.Inventory;
import com.springsecurity.react.model.Order;
import com.springsecurity.react.inventory.InventoryRepository;
import jakarta.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService{
    private static final Logger log = LogManager.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    @Override
    public List<Order> findAll() {
        log.info("---OrderServiceImpl with findAll method-----");
        return orderRepository.findAll();
    }

    @Override
    public Order save(Order order) {
        log.info("---OrderServiceImpl with Save method-----");
        Inventory inventory = inventoryRepository.findByProduct(order.getOrderItem());
        if (inventory.getQuantity() < order.getQuantity()) {
           throw new OrderRunTimeException("Quantity is Exceeded please check in Inventory..!");
        }
        return orderRepository.save(order);
    }
    @Override
    public void update(Long id, Order order) {
        log.info("---OrderServiceImpl with Update method-----");
        Optional<Order> orderObj = orderRepository.findById(id);
        if (orderObj.isPresent()) {
            Order orderUpdateObj = orderObj.get();
            orderUpdateObj.setOrderItem(order.getOrderItem());
            orderUpdateObj.setAmount(order.getAmount());
            orderUpdateObj.setOrderDate(order.getOrderDate());
            orderUpdateObj.setStatus("Accepted");
            orderUpdateObj.setQuantity(order.getQuantity());
            orderRepository.save(orderUpdateObj);
        }

    }
    @Override
    public void delete(Long id) {
        log.info("---OrderServiceImpl with Delete method-----");
        orderRepository.deleteById(id);
    }
}
