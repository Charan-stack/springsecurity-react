package com.springsecurity.react.config;

import com.springsecurity.react.signup.SignUpRepository;
import io.jsonwebtoken.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtTokenGenerator {

    private static final Logger log = LogManager.getLogger(JwtTokenGenerator.class);

    @Value("${jwt.secrete.key}")
    private String SECRET_KEY;

    @Value("${jwt.token.expiration}")
    private Long JWT_TOKEN_EXPIRATION;

    @Value("${jwt.refreshtoken.expiration}")
    private Long JWT_REFRESH_TOKEN_EXPIRATION;

    @Autowired
    private SignUpRepository signUpRepository;


    public String generateToken(Long id,String username, String role) {
        log.info("----JwtTokenGenerator Generating the Jwt token in generateToken method----");
        return Jwts.builder()
                .setSubject(username)
                .claim("role", role)
                .claim("id", id)
                .setAudience(role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_EXPIRATION))  // 1-day expiration
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }

    public String generateRefreshToken(String username) {
        log.info("----JwtTokenGenerator Generating the Refresh token in generateRefreshToken method----");
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + JWT_REFRESH_TOKEN_EXPIRATION))  // 5-day expiration
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }

    public String extractUsername(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    public boolean validateToken(String token, String username) {
        String usernameFromToken = extractUsername(token);
        return (usernameFromToken.equals(username) && !isTokenExpired(token));
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody()
                .getExpiration();
    }
}


