package com.springsecurity.react.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ExceptionResponse.class)
    public ResponseEntity<ErrorResponse> handlingSignupExceptionHandler(ExceptionResponse ex) {
       ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), "User Already Exits.!");
        return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(OrderRunTimeException.class)
    public ResponseEntity<OrderExceptionResponse> handlingExceptionForOrder (OrderRunTimeException errorResponse) {
        OrderExceptionResponse ex = new OrderExceptionResponse(HttpStatus.BAD_REQUEST.value(), "Quantity Is exceeded..!");
        return new ResponseEntity<OrderExceptionResponse>(ex, HttpStatus.BAD_REQUEST);
    }
}
