package com.springsecurity.react.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderExceptionResponse {

    private int status;
    private String message;

    private OrderExceptionResponse(String message) {
        super();
        this.message = message;
    }
}
