package com.springsecurity.react.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
@EnableJdbcRepositories(
        basePackages = "com.springsecurity.react"
)
@Profile("jdbc")
public class JDBCTemplateConfig {

    @Bean("jdbcDataSource")
    public DataSource dataSource() {
        return DataSourceBuilder.create()
                .username("root")
                .password("Root@123")
                .url("jdbc:mysql://localhost:3307/springsecurity")
                .driverClassName("com.mysql.cj.jdbc.Driver")
                .build();
    }

    @Bean(name = "jdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("jdbcDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
